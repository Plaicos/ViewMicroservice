module.exports = {
    home: require("./home.marko"),
    checkout: require("./checkout.marko"),
    sign_in: require("./sign_in.marko"),
    login: require("./login.marko"),

    //logged user
    dashboard: require("./dashboard.marko"),

    //components
    plans: require("./plans.marko")
}