// Compiled using marko@4.18.24 - DO NOT EDIT
"use strict";

var marko_template = module.exports = require("marko/src/html").t(__filename),
    marko_componentType = "/view_microservice$1.0.0/src/app/entitties/main/view/templates_library/templates/home.marko",
    components_helpers = require("marko/src/runtime/components/helpers"),
    marko_renderer = components_helpers.r,
    marko_defineComponent = components_helpers.c,
    marko_helpers = require("marko/src/runtime/html/helpers"),
    marko_loadTag = marko_helpers.t,
    component_globals_tag = marko_loadTag(require("marko/src/core-tags/components/component-globals-tag")),
    marko_attr = marko_helpers.a,
    init_components_tag = marko_loadTag(require("marko/src/core-tags/components/init-components-tag")),
    await_reorderer_tag = marko_loadTag(require("marko/src/core-tags/core/await/reorderer-renderer"));

function render(input, out, __component, component, state) {
  var data = input;

  out.w("<!DOCTYPE html><html data-wf-page=\"5dcb535bc74abf62fcf7fcba\" data-wf-site=\"5dcb535bc74abf03fdf7fcb7\"><head><meta charset=\"utf-8\"><title>Business - Webflow HTML website template</title><meta content=\"Business - Webflow HTML website template\" property=\"og:title\"><meta content=\"https://uploads-ssl.webflow.com/5c6eb5400253230156de2bd6/5cdc268dd7274d5c05c6009a_Business%20SEO.jpg\" property=\"og:image\"><meta content=\"width=device-width, initial-scale=1\" name=\"viewport\"><meta content=\"Webflow\" name=\"generator\"><link href=\"/public/css/normalize.css\" rel=\"stylesheet\" type=\"text/css\"><link href=\"/public/css/webflow.css\" rel=\"stylesheet\" type=\"text/css\"><link href=\"/public/css/plaicos.webflow.css\" rel=\"stylesheet\" type=\"text/css\"><script src=\"https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js\" type=\"text/javascript\"></script><script type=\"text/javascript\">WebFont.load({  google: {    families: [\"Montserrat:100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic\"]  }});</script><script type=\"text/javascript\">!function(o,c){var n=c.documentElement,t=\" w-mod-\";n.className+=t+\"js\",(\"ontouchstart\"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+\"touch\")}(window,document);</script><link href=\"/public/images/favicon.ico\" rel=\"shortcut icon\" type=\"image/x-icon\"><link href=\"/public/images/webclip.png\" rel=\"apple-touch-icon\"></head><body>");

  component_globals_tag({}, out);

  out.w("<div data-collapse=\"medium\" data-animation=\"default\" data-duration=\"400\" class=\"navigation w-nav\"><div class=\"navigation-wrap\"><a href=\"/\" class=\"logo-link w-nav-brand w--current\"><img src=\"/public/images/PLAICOS-LOGO.png\" width=\"108\" srcset=\"/public/images/PLAICOS-LOGO-p-500.png 500w, /public/images/PLAICOS-LOGO-p-800.png 800w, /public/images/PLAICOS-LOGO.png 1047w\" sizes=\"(max-width: 479px) 100vw, 108px\" alt=\"\" class=\"logo-image\"></a><div class=\"menu\"><nav role=\"navigation\" class=\"navigation-items w-nav-menu\"><a href=\"/\" class=\"navigation-item w-nav-link w--current\">HOMe</a><a" +
    marko_attr("href", (data.links.view + "?params=") + data.links.web.public.marketplace) +
    " class=\"navigation-item w-nav-link\">marketplace</a><a href=\"team.html\" class=\"navigation-item w-nav-link\">equipe</a><a href=\"blog.html\" class=\"navigation-item w-nav-link\">Blog</a><a href=\"contact.html\" class=\"navigation-item w-nav-link\">contato</a><a" +
    marko_attr("href", (data.links.view + "?params=") + data.links.web.public.sign_in) +
    " class=\"nav-link w-nav-link\">CADASTRE-SE</a><a" +
    marko_attr("href", (data.links.view + "?params=") + data.links.web.public.login) +
    " class=\"nav-link-2 w-nav-link\">LOGIN</a></nav><div class=\"menu-button w-nav-button\"><img src=\"/public/images/menu-icon_1menu-icon.png\" width=\"22\" alt=\"\" class=\"menu-icon\"></div></div></div><div data-delay=\"0\" class=\"dropdown-2 w-dropdown\"><div class=\"dropdown-toggle-3 w-dropdown-toggle\"><div class=\"w-icon-dropdown-toggle\"></div><div>MINHA CONTA</div></div><nav class=\"dropdown-list w-dropdown-list\"><a href=\"#\" class=\"w-dropdown-link\">MEU PERFIL</a><a href=\"#\" class=\"w-dropdown-link\">DASHBOARD</a><a href=\"#\" class=\"w-dropdown-link\">SAIR</a></nav></div></div><div data-w-id=\"c7bdb09e-d193-5092-0ae4-45323f6aeed1\" class=\"section-5\"><div data-w-id=\"42cfd933-8ff1-a6c0-7a9c-d7a0fc371735\" class=\"div-block-15\"><div data-w-id=\"cca432eb-68d2-4ce2-b36b-b0bdb7c2f85c\" style=\"display:block\" class=\"div-block-16\"><div class=\"w-form\"><form id=\"email-form\" name=\"email-form\" data-name=\"Email Form\"><label for=\"name\">login</label><input type=\"text\" class=\"w-input\" maxlength=\"256\" name=\"name\" data-name=\"Name\" placeholder=\"LOGIN\" id=\"name\" required=\"\"><label for=\"email\">senha</label><input type=\"password\" class=\"w-input\" maxlength=\"256\" name=\"email\" data-name=\"Email\" placeholder=\"SENHA\" id=\"email\" required=\"\"><input type=\"submit\" value=\"LOGIN\" data-wait=\"Please wait...\" class=\"w-button\"></form><div class=\"w-form-done\"><div>Thank you! Your submission has been received!</div></div><div class=\"w-form-fail\"><div>Oops! Something went wrong while submitting the form.</div></div></div></div></div></div><div class=\"section-3\"></div><div class=\"section cc-store-home-wrap\"><div class=\"intro-header\"><div class=\"intro-content cc-homepage\"><div class=\"intro-text\"><div class=\"heading-jumbo\">HUB da industria cosmética</div><div class=\"paragraph-bigger cc-bigger-white-light\">Anuncie e venda de forma rápida, prática e transparente<br></div></div><a href=\"about.html\" class=\"button cc-jumbo-button cc-jumbo-white w-inline-block\"><div>saiba mais</div></a></div></div><div class=\"container\"><div class=\"motto-wrap\"><div class=\"label cc-light\">INOVAÇÃO NO MERCADO</div><div class=\"heading-jumbo-small\">Descubra como a Plaicos vai crescer suas vendas e dar um boost em seu negócio<br></div></div><div class=\"divider\"></div><div class=\"home-content-wrap\"><div class=\"w-layout-grid about-grid\"><div id=\"w-node-76c147234d34-fcf7fcba\"><div class=\"home-section-wrap\"><div class=\"label cc-light\">SOBRE NÓS</div><h2 class=\"section-heading\">O QUE É PLAICOS</h2><p class=\"paragraph-light\">Nulla vel sodales tellus, quis condimentum enim. Nunc porttitor venenatis feugiat. Etiam quis faucibus erat, non accumsan leo. Aliquam erat volutpat. Vestibulum ac faucibus eros. Cras ullamcorper gravida tellus ut consequat.</p></div><a href=\"about.html\" class=\"button w-inline-block\"><div>Learn More</div></a></div><img src=\"images/placeholder-3.svg\" id=\"w-node-76c147234d3f-fcf7fcba\" alt=\"\"></div><div class=\"w-layout-grid about-grid cc-about-2\"><div id=\"w-node-76c147234d41-fcf7fcba\"><div class=\"home-section-wrap\"><div class=\"label cc-light\">plataforma profissional</div><h2 class=\"section-heading\">COMO OPERAMOS?</h2><p class=\"paragraph-light\">Nulla vel sodales tellus, quis condimentum enim. Nunc porttitor venenatis feugiat. Etiam quis faucibus erat, non accumsan leo. Aliquam erat volutpat. Vestibulum ac faucibus eros. Cras ullamcorper gravida tellus ut consequat.</p></div><a href=\"team.html\" class=\"button w-inline-block\"><div>Learn More</div></a></div><img src=\"images/placeholder-1.svg\" id=\"w-node-76c147234d4c-fcf7fcba\" alt=\"\"></div></div></div></div><div class=\"section\"><div class=\"container\"><div class=\"blog-heading\"><div class=\"label cc-light\">FIQUE ATUALIZADO</div><h2 class=\"work-heading\">NOVIDADES</h2></div><div class=\"collection-list-wrapper w-dyn-list\"><div class=\"collection-wrap w-dyn-items\"><div class=\"blog-preview-wrap w-dyn-item\"><a href=\"#\" class=\"business-article-heading\"></a><div class=\"label cc-blog-date\"></div><p class=\"paragraph-light\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla, ut commodo diam libero vitae erat. Aenean faucibus nibh et justo cursus id rutrum lorem imperdiet. Nunc ut sem vitae risus tristique posuere.</p></div></div><div class=\"status-message cc-no-data w-dyn-empty\"><div>No items found.</div></div></div></div></div><div class=\"section cc-cta\"><div class=\"container\"><div class=\"cta-wrap\"><div><div class=\"cta-text\"><div class=\"heading-jumbo-small\">FAÇA PARTE DA NOVA ERA <br></div><div class=\"paragraph-bigger cc-bigger-light\">Seja um dos pioneiros a se juntar a Plaicos e seus parceiros, conquiste sua consolidação no novo HUB do mercado cosmético.<br></div></div><a href=\"contact.html\" class=\"button cc-jumbo-button w-inline-block\"><div>COMEÇAR AGORA</div></a></div></div></div></div><div class=\"section\"><div class=\"container\"><div class=\"footer-wrap\"><a href=\"https://webflow.com/\" target=\"_blank\" class=\"webflow-link w-inline-block\"><img src=\"/public/images/webflow-w-small2x_1webflow-w-small2x.png\" width=\"15\" alt=\"\" class=\"webflow-logo-tiny\"><div class=\"paragraph-tiny\">Powered by Webflow</div></a></div></div></div><script src=\"https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.4.1.min.220afd743d.js\" type=\"text/javascript\" integrity=\"sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=\" crossorigin=\"anonymous\"></script><script src=\"/public/js/webflow.js\" type=\"text/javascript\"></script>");

  init_components_tag({}, out);

  await_reorderer_tag({}, out, __component, "116");

  out.w("</body></html>");
}

marko_template._ = marko_renderer(render, {
    ___implicit: true,
    ___type: marko_componentType
  });

marko_template.Component = marko_defineComponent({}, marko_template._);

marko_template.meta = {
    id: "/view_microservice$1.0.0/src/app/entitties/main/view/templates_library/templates/home.marko",
    tags: [
      "marko/src/core-tags/components/component-globals-tag",
      "marko/src/core-tags/components/init-components-tag",
      "marko/src/core-tags/core/await/reorderer-renderer"
    ]
  };
